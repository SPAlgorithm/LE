LADHE VERIFICATION KIT
======================

This bundle contains a digitally signed document and the tools to
verify it. The signature was produced with Ladhe, a one-time
hash-based signature scheme whose security reduces to SHA-256
preimage resistance (paper: https://zenodo.org/records/19795884).

CONTENTS
--------
  verify.py              standalone verifier (no installs needed)
  ca.cert.pem            the certificate authority's cert (Ladhe-native)
  alice.cert.pem         the signer's cert (Ladhe-native)
  ca.x509.pem            the CA's cert in standard X.509 PEM format
  alice.x509.pem         Alice's cert in standard X.509 PEM format
  purchase_order.txt            the signed document
  purchase_order.txt.sig        Alice's signature on the document
  README.txt             this file

REQUIREMENTS
------------
  Python 3.9 or newer. That's it. No pip install. No virtualenv.
  (The optional X.509 demo at the end uses openssl, which is
   already on every Mac, Linux, and Windows machine.)

VERIFY EVERYTHING (the easy way)
---------------------------------
  cd ladhe_demo_kit
  python3 verify.py

  Expected last line: "All verifications passed."

ATTEMPT A TAMPER (the demo's punchline)
----------------------------------------
  1. Open  purchase_order.txt  in your editor.
  2. Change ANY single byte (one digit, one letter - anything).
  3. Save the file.
  4. Re-run:    python3 verify.py
  5. The signature check should now FAIL - that's the math
     catching the tampering.
  6. Restore the file from the original and verify again - passes.

EXPLICIT MODE (per-step)
------------------------
  python3 verify.py verify-cert alice.cert.pem ca.cert.pem
  python3 verify.py verify-doc  purchase_order.txt  purchase_order.txt.sig  alice.cert.pem

BONUS: STANDARD X.509 INTEROPERABILITY (uses openssl)
------------------------------------------------------
The two .x509.pem files are the SAME certificates, exported
in standard X.509 v3 format (ASN.1 DER inside PEM). Any
openssl on any machine can parse them:

    openssl x509 -in alice.x509.pem -text -noout

You will see fields like:

    Signature Algorithm: 1.3.6.1.4.1.65644.1.1
    Issuer: CN=Acme Quantum CA
    Subject: CN=alice@acme.com
    Public Key Algorithm: 1.3.6.1.4.1.65644.1.2

The OID 1.3.6.1.4.1.65644.1.1 is registered with IANA to
LeSecure (Private Enterprise Number 65644, April 2026).
Openssl will print "Unable to load Public Key" because it
does not yet have a provider plugin for Ladhe — that is
the next engineering milestone. The cert STRUCTURE is fully
X.509 v3 compliant, which is what this part of the demo
is meant to show.

Walk the ASN.1 tree if you are curious:

    openssl asn1parse -in alice.x509.pem | head -30

QUESTIONS / FEEDBACK
--------------------
  spalgorithm@gmail.com

Thank you for taking the time to test this.
